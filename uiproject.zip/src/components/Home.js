import React from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom"
//import "./App.css";

function Home() {
    const { register, handleSubmit, formState: { errors } } = useForm();
    const onSubmit = (data) => console.log(data);
    return (
        <>
            <p className="title">Home Form</p>

        </>
    );
}
export default Home;